package com.noriutsugii.pristine

import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.*
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.*


class MainActivity : AppCompatActivity() {
    private val REQUEST_ENABLE_BT:Int = 1

    private var BT_STATE:Int = 0

    lateinit var bluetoothAdapter: BluetoothAdapter
    lateinit var context: Context
    lateinit var textConnectionStatus: TextView
    lateinit var textStatus: TextView

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            this.supportActionBar!!.hide()
        } catch (e: NullPointerException) {
        }
        setContentView(R.layout.activity_main)
        context = this

        textConnectionStatus = findViewById(R.id.textConnectionStatus)
        textStatus = findViewById(R.id.textStatus)

        val btnTurnOn = findViewById<Button>(R.id.btnTurnOn)
        val btnPair = findViewById<Button>(R.id.btnPair)
        val btnDisconnect = findViewById<Button>(R.id.btnDisconnect)
        val btnConnect = findViewById<Button>(R.id.btnConnect)

        //val device: BluetoothDevice = BluetoothAdapter.getRemote ("D4:36:39:6F:7F:0E")

        fun viewTurnOn(bool: Boolean){
            if (bool == true) {
                btnTurnOn.visibility= View.VISIBLE
                btnTurnOn.isClickable=true
            } else if (bool == false) {
                btnTurnOn.isClickable=false
                btnTurnOn.visibility= View.INVISIBLE
            }
        }

        fun viewPair(bool: Boolean){
            if (bool == true) {
                btnPair.visibility= View.VISIBLE
                btnPair.isClickable=true
            } else if (bool == false) {
                btnPair.isClickable=false
                btnPair.visibility= View.INVISIBLE
            }
        }

        fun viewDisconnect(bool: Boolean){
            if (bool == true) {
                btnDisconnect.visibility= View.VISIBLE
                btnDisconnect.isClickable=true
            } else if (bool == false) {
                btnDisconnect.isClickable=false
                btnDisconnect.visibility= View.INVISIBLE
            }
        }
        fun viewConnect(bool: Boolean){
            if (bool == true) {
                btnConnect.visibility= View.VISIBLE
                btnConnect.isClickable=true
            } else if (bool == false) {
                btnConnect.isClickable=false
                btnConnect.visibility= View.INVISIBLE
            }
        }

        viewConnect(false)
        viewDisconnect(false)
        viewPair(false)
        viewTurnOn(false)

        btnTurnOn?.setOnClickListener(){
            if (!bluetoothAdapter.isEnabled){
                val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)
            } else {
                viewTurnOn(false)
                viewPair(true)
            }
        }

        btnPair?.setOnClickListener(){
            if (!bluetoothAdapter.isEnabled){
                viewPair(false)
                viewTurnOn(true)
            } else {
                getPairedDev()
                viewPair(false)
            }
        }


        if(enableBluetooth()) {
            if (!bluetoothAdapter.isEnabled) {
                viewTurnOn(true)
            } else {
                viewTurnOn(false)
                viewPair(true)
                socketStuff()
            }
        }
    }
    fun socketStuff(){
        CoroutineScope(Dispatchers.Default).launch {
            var result = SPPconnect.acceptConnection(bluetoothAdapter)
            if (result.equals("Accepted")) {
                Toast.makeText(context, String.format("Received a call"), Toast.LENGTH_LONG)
                    .show();
            }
        }
    }

    fun enableBluetooth(): Boolean {
        val bluetoothManager = this.getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter

        if (bluetoothManager == null) {
            textConnectionStatus.text = "bluetooth is not available"
            return false
        } else {
            textConnectionStatus.text = "bluetooth is available"
            return true
        }
    }

    @SuppressLint("MissingPermission")
    fun getPairedDev() {
        textConnectionStatus.text = "Paired dev"
        val devices = bluetoothAdapter.bondedDevices
        for (device in devices){
            val deviceName = device.name
            val deviceAddress = device
            textStatus.append("\n $deviceName, $deviceAddress")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val btnTurnOn = findViewById<Button>(R.id.btnTurnOn)
        val btnPair = findViewById<Button>(R.id.btnPair)
        when(requestCode) {
            REQUEST_ENABLE_BT ->
                if (resultCode == Activity.RESULT_OK) {
                    btnTurnOn.isClickable=false
                    btnTurnOn.visibility= View.INVISIBLE
                    btnPair.isClickable=true
                    btnPair.visibility= View.VISIBLE
                    textConnectionStatus.text = "bluetooth has been turned on"
                } else {
                    textConnectionStatus.text = "Unable to turn on bluetooth "
                    btnTurnOn.visibility= View.VISIBLE
                    btnTurnOn.isClickable=true
                }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

}


class SPPconnect {

    companion object {
        lateinit var ServerSocket: BluetoothServerSocket        // The local server socket
        lateinit var socket: BluetoothSocket                    // socket used for communication

        val A_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        val A_NAME = "BluetoothServer"

        suspend fun acceptConnection(btadapter: BluetoothAdapter): String {
            val BTadapter: BluetoothAdapter = btadapter

            try {
                ServerSocket = BTadapter.listenUsingRfcommWithServiceRecord(A_NAME, A_UUID)
                socket = ServerSocket.accept()
            }catch(e:SecurityException){
            }

            // a call has been accepted
            ServerSocket.close() // Close the local Server Socket

            return "Accepted"
        }
    }
}